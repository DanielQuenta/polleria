import { Link } from "react-router-dom";

export function Sidebar() {
  return (
    <aside className="w-64 bg-white shadow-md">
      <div className="p-4 font-bold text-lg">Delivery Dashboard</div>
      <nav className="flex flex-col gap-2 p-4">
        <Link to="/" className="hover:text-blue-500">Dashboard</Link>
        <Link to="/orders" className="hover:text-blue-500">Pedidos</Link>
        <Link to="/customers" className="hover:text-blue-500">Clientes</Link>
        <Link to="/reports" className="hover:text-blue-500">Reportes</Link>
      </nav>
    </aside>
  );
}
