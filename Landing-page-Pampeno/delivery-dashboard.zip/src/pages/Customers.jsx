export function Customers() {
  return <h1 className="text-2xl font-bold">Clientes</h1>;
}
