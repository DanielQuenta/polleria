export function Orders() {
  return <h1 className="text-2xl font-bold">Pedidos</h1>;
}
