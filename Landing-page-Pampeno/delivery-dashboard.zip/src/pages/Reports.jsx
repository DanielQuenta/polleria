export function Reports() {
  return <h1 className="text-2xl font-bold">Reportes</h1>;
}
